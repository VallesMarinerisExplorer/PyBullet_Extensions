wm_height_out.png and gimp_overlay_out assets from this Blender tutorial:
https://www.beamng.com/threads/tutorial-adding-heightmap-roads-using-blender.16356/

groundX.txt assets from DeepLoco, used with permission from Jason Peng.